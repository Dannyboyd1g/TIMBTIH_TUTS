<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include("assets/includes/css_headers.html"); ?>
    <link rel="stylesheet" href="assets/css/fake_news.css">
    <title>TIMBTIH NEWS | HOME</title>
</head>
<body>
    <header role="banner" class="fixed-top" id="header">
        <div class="top_image_holder">
            <img src="assets/images/TIMBTIH_1.gif" alt="Site logo">
        </div>
        <nav class="navbar navbar-expand-lg bg-blue">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <div>
                <li class="nav-item">
                        <a class="nav-link" href="#">Latest news<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link low_contrast" href="#">Sponsors</a>
                    </li>
                </div>
                <form class="form-inline my-2 my-lg-0 nav-form">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><span class="span1">Search</span><span class="span2"><i class="fa fa-search"></i></span></button>
                </form>
                <li class="nav-item f-right">
                    <a class="nav-link disabled" href="#"><i class="fa fa-instagram"></i></a>
                </li>
              </ul>
            </div>
        </nav>
    </header>
    <main class="row">
        <div class="main_content col-md-8 col-sm-12">
            <article class="home container-fluid card">
                <img class="card-img" src="assets/images/vlcsnap-error229.png" alt="Fake news">
                <div class="card-body">
                    <p>The world wouldn't just be the same without it; it has changed the world over the years with it's efficiency in 
                        getting the attention of the good people. 
                        It provides vital information on what's not going on in our society and the world at large.
                        But the culture is slowly dying.
                        We at <b>The Impractical Mad Banana Tribe -of Impractical Hackers (TIMBTIH)</b> oblige and challenge ourselves to serve you the most accurate fake news that there is across
                        various sectors of the everyday
                    </p>
                </div>
            </article>
            <section class="news">
                <div class="card newspaper">
                    <h4>Latest f<span class="u-orange">ake news:</span></h4>
                    <div class="card-body newspaper_body">
                        <div class="column1">
                            <div class="card mb-2 box-shadow news_card">
                                
                                <div class="card-body">
                                    <h4>Grand lottery</h4>
                                  <p class="card-text">Woman arrested for defecating on boss' desk after lottery.</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">2 secs</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                
                                <div class="card-body">
                                    <h4>Meth-lab explosion</h4>
                                  <p class="card-text">Florida man dies in meth-lb explosion after lighting farts on fire.</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">1 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                <img class="card-img-top" src="assets/images/qoe.jfif" alt="Card image cap">
                                <div class="card-body">
                                    <h4>The Queen to launch a brand new album.</h4>
                                  <p class="card-text">Coming up this Friday</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">1 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card hidden">
                                <img class="card-img-top" src="assets/images/crush.jfif" alt="Card image cap">
                                <div class="card-body">
                                    <h4> Woman murders roommate for sending too many Candy Crush requests</h4>
                                  <p class="card-text">sentence to be heard</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">3 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card hidden">
                                
                                <div class="card-body">
                                    <h4>Online advertisers being robbed blind</h4>
                                  <p class="card-text">By some sneaky websites</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">3 d</small>
                                  </div>
                                </div>
                            </div>
                            
                        </div>

                        <div class="column2">
                            <div class="card mb-2 box-shadow news_card">
                                <img class="card-img-top" src="assets/images/clinton.jfif" alt="Card image cap">
                                <div class="card-body">
                                    <h4>Hilary Clontin says she's a cannibal.</h4>
                                  <p class="card-text">She announced it on Tuesday</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">9 secs</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                <div class="card-body">
                                    <h4>Alien stunts</h4>
                                  <p class="card-text">Florida man claims that he got kidnapped by aliens also claims that “Climate changes aren’t real”

                                </p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">1 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                
                                <div class="card-body">
                                   <h4> Raelian offsite</h4>
                                  <p class="card-text">
                                    
                                    The Elohim embasssy in Russia is not an embarrasment. Alexrie Navalny is.</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">2 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                <img class="card-img-top" src="assets/images/bridge.jpg" alt="Card image cap">
                                <div class="card-body">
                                    <h4>London bridge is brown
                                        
                                        </h4>
                                  <p class="card-text">Hitler wanted one territory more than any other but failed.

                                </p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">3d</small>
                                  </div>
                                </div>
                            </div>
                        </div>

                        <div class="column3">
                            <div class="card mb-2 box-shadow news_card">
                                <img class="card-img-top" src="assets/images/ww3.jfif" alt="Card image cap">
                                <div class="card-body">
                                    <h4>WW3 is occurring in secret and nobody knows</h4>
                                  <p class="card-text">We could all die. Secret nuclear missiles have been fired all over the planet.

                                </p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">9 mins</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                
                                <div class="card-body">
                                    <h4>And the world ducked</h4>
                                  <p class="card-text">Pisney Enterprises upset about copyright infringement by US president

                                </p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">1 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card">
                                <img class="card-img-top" src="assets/images/vlcsnap-error391.png" alt="Card image cap">
                                <div class="card-body">
                                    <h4>Services memoriam for Jeremoah Devis</h4>
                                  <p class="card-text">Services memoriam for Jeremoah Devis, whom fell Friday 24 May 2019.

                                    </p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">2 d</small>
                                  </div>
                                </div>
                            </div>
                            <div class="card mb-2 box-shadow news_card hidden">
                                <img class="card-img-top" src="assets/images/vlcsnap-error391.png" alt="Card image cap">
                                <div class="card-body">
                                    <h4>Canada's secret army</h4>
                                  <p class="card-text">An ex-vine star located a secret Canadian military base where they are secretly training Sasquatch.
</p>
                                  <div class="d-flex justify-content-between align-items-center">
                                    <div class="btn-group">
                                      <button type="button" class="btn btn-sm btn-outline-secondary"><i class="fa fa-forward"></i></button>
                                    </div>
                                    <small class="text-muted">3 d</small>
                                  </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="seeMore">See More-</button>
                    </div>

                    
                <section class="sponsors">
                    <div class="home container-fluid card">
                        <div class="card-body">
                            <p><b>None of this would have been made possible without our excellent sponsors</b></p>
                            <div class="row" style="text-align: center;">
                                <div class="col-md-12">
                                    <img src="assets/images/mlh.jfif" alt="" style="width: 200px;">
                                <p>Mayor League Hackin</p>
                                </div>
                                
                            </div>
                            <div class="row"style="text-align: center;">
                                <div class="col-md-6">
                                    <img src="assets/images/toogle.jfif" alt="" style="width: 200px;">
                                <p>TOOGLE</p>
                                </div>
                                <div class="col-md-6">
                                    <img src="assets/images/husk.jfif" alt="" style="width: 200px;">
                                <p>Elon Husk</p>
                                </div>
                            </div>
                            <div class="row" style="text-align: center;">
                                <div class="col-md-12">
                                    <img src="assets/images/biden.jfif" alt="" style="width: 200px;">
                                    <p>And ofcourse... President Joe Bidin</p>
                                </div>
                            </div>
                    </div>
                </section>
            </section>
            
        </div>
        
        <section class="contact col-md-4 col-sm-12" style="position:sticky; position: -webkit-sticky;">
            <div class="card" style="padding: 8px">
                <h4>Wanna get notified when we post something new?</h4>
                <form>
                    <div class="form-group">
                    
                      <label for="exampleFormControlInput1">Email address</label>
                      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                    </div>
                    <div class="form-group">
                      <label for="exampleFormControlTextarea1">Leave a word:</label>
                      <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </form>
            </div>
        </section>
    </main>




    <script src="assets/js/jquery-3.5.1.min.js"></script>
    <script src="assets/js/fake_news.js"></script>
    <script src="assets/css/bootstrap-4.0.0/dist/js/bootstrap.min.js"></script>
</body>
</html>