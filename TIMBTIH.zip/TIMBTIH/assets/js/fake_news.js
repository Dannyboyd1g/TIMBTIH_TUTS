
$(function () {
    var body = document.getElementsByTagName("body")[0],
    header = document.getElementById("header");
    body.style.paddingTop = header.clientHeight+15+"px";

    

    hiddens = document.getElementsByClassName("hidden");
    // hiddens.forEach(element => {
    //     console.log(element.classList);
    // });


    document.getElementById("seeMore").addEventListener("click", function (e) {
            for (let i = 0; i < hiddens.length; i++) {
                console.log("hiddens")
                console.log(hiddens[i].classList);
                hiddens[i].classList.remove("hidden");
            }
            console.log("Okay.");
            $(".hidden").removeClass(".hidden");
    });
    
    
});